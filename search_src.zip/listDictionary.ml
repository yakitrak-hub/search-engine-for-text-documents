open Dictionary

(** [format_assoc_list fmt_key fmt_val fmt lst] formats an association 
    list [lst] as a dictionary.  The [fmt_key] and [fmt_val] arguments
    are formatters for the key and value types, respectively.  The
    [fmt] argument is where to put the formatted output. *)
let format_assoc_list format_key format_val fmt lst =
  (*BISECT-IGNORE-BEGIN*)
  Format.fprintf fmt "[";
  List.iter (fun (k,v) -> Format.fprintf fmt "%a -> %a; "
                format_key k format_val v) lst;
  Format.fprintf fmt "]"
(*BISECT-IGNORE-END*)

module Make : DictionaryMaker
  = functor (K : KeySig) -> functor (V : ValueSig) ->
  struct
    (** [Key] is a module representing the type of keys
        in the dictionary and functions on them. *)
    module Key = K

    (** [Value] is a module representing the type of values
        in the dictionary and functions on them. *)
    module Value = V

    (** [key] is the type of keys in the dictionary. *)
    type key = K.t

    (** [value] is the type of values in the dictionary. *)
    type value = V.t


    (* AF: The association list [(k1,v1);(k2,v2);....;(kn,vn)] 
       represents the dictionary which is map from k1->v1, k2->v2 ... kn -> vn. 
     * RI: The keys in the association list are unique, i.e one key can 
       only map to one value although the same value can map to multiple keys. 
    *)

    (** [t] is the type of dictionaries. *) 
    type t = (key * value) list

    (** [rep_ok d] returns [d] if [d] satisfies its representation
        invariants. It's unusual for a data abstraction to
        expose this function to its clients, but we do so here
        to ensure that you implement it.
        Raises: [Failure] with an unspecified error message
        if [d] does not satisfy its representation invariants. *)
    let rep_ok d =
      (*BISECT-IGNORE-BEGIN*)
      let key_compare = 
        (fun a b -> match K.compare a b with
           |EQ -> 0
           |LT -> -1
           |GT -> 1) in
      let num_uniq_keys = List.(d |> map fst |> sort_uniq key_compare |> length) in
      let num_keys = List.length d in
      if num_keys = num_uniq_keys 
      then d else failwith "RI"
    (*BISECT-IGNORE-END*)
    (** [empty] is the empty dictionary *)
    let empty = [] 

    (** [is_empty d] is [true] iff [d] is empty. *)
    let is_empty d =
      d = []
    (** [size d] is the number of bindings in [d]. *
        [size empty] is [0]. *)
    let size d =
      List.length d

    (** [insert k v d] is [d] with [k] bound to [v]. If [k] was already
        bound, its previous value is replaced with [v]. *)
    let insert k v d =
      let d' = if List.mem_assoc k d then List.remove_assoc k d else d in
      (k,v)::d'

    (** [remove k d] contains all the bindings of [d] except
        a binding for [k].  If [k] is not bound in [d], then
        [remove] returns a dictionary with the same bindings
        as [d]. *)
    let remove k d =
      List.remove_assoc k d

    (** [find k d] is [Some v] if [k] is bound to [v] in [d]; or
        if [k] is not bound, then it is [None]. *)
    let find k d =
      try Some(List.assoc k d) with 
      | Not_found -> None

    (** [member k d] is [true] iff [k] is bound in [d]. *)
    let member k d =
      List.mem_assoc k d

    (** [choose d] is [Some (k,v)], where [k] is bound to [v]
        in [d].  It is unspecified which binding of [d] is
        returned.  If [d] is empty, then [choose d] is [None]. *)
    let choose d =
      if d = empty then None else Some (List.nth d (Random.int ( (List.length d ))) )

    (** [key_comparator k1 k2] is K.compare but returns value of type int
        instead of Dictionary.order. *)
    let key_comparator k1 k2 = 
      match K.compare k1 k2 with 
      | EQ -> 0
      | LT -> -1
      | GT -> 1

    (** [to_list d] is an association list containing the same
        bindings as [d].  The  elements in the list are
        in order from the least key to the greatest. *)
    let to_list d =
      let key_list = List.sort key_comparator (List.map fst d) in
      let value_list = List.map (fun x -> List.assoc x d) key_list in
      List.combine key_list value_list

    (** [fold f init d] is [f kn vn (f ... (f k1 v1 init) ...)],
        if [d] binds [ki] to [vi].  Bindings are processed
        in order from least to greatest, where [k1] is the
        least key and [kn] is the greatest. *)
    let rec fold f init d =
      let dlist = to_list d in 
      match dlist with 
      | [] -> init
      | (k,v)::t -> fold f (f k v init) t

    (** [format] is a printing function suitable for use
        with the toplevel's [#install_printer] directive.
        It outputs a textual representation of a dictionary
        on the given formatter. *)
    let format fmt d =
      (*BISECT-IGNORE-BEGIN*)
      format_assoc_list K.format V.format fmt d
      (*BISECT-IGNORE-END*)

  end
