module type Engine = sig
  type idx
  val index_of_dir : string -> idx
  val words : idx -> string list
  val to_list : idx -> (string * string list) list
  val or_not  : idx -> string list -> string list -> string list
  val and_not : idx -> string list -> string list -> string list
  val format : Format.formatter -> idx -> unit
end

module Make = 
  functor (S:DictionarySet.Set with type Elt.t = string)
    -> functor (D:Dictionary.Dictionary with type Key.t = string
                                         and type Value.t = S.t) 
    -> struct


      type idx = D.t

      (** takes a string and a set and adds the words in the 
          string into the words set*)
      let string_to_words s init_words =
        let mid_word_reg = "[^A-Za-z0-9]*[ \n\r\x0c\t][^A-Za-z0-9]*" in
        let start_word_reg = "\\([^A-Za-z0-9]+$\\)" in
        let last_word_reg = "\\(^[^A-Za-z0-9]+\\)" in
        let r = Str.regexp (mid_word_reg ^ "\\|" 
                            ^ start_word_reg ^ "\\|"
                            ^ last_word_reg) in
        let words_list = Str.split r s in
        let f acc x = S.insert (String.lowercase_ascii x) acc in
        List.fold_left f init_words words_list

      (** takes an in_channel reader and words set and add the words in 
          the reader into words set*)
      let rec read_line r s =
        match Pervasives.input_line r with
        | exception End_of_file -> Pervasives.close_in r; s
        | line -> 
          let new_words = (string_to_words line s) in
          read_line r new_words

      (** takes a directory and a filename, and outputs set of words inside that file
          all the words are lowercased*)
      let file_to_words (dir:string) (filename:string) : S.t =
        let file = dir ^ Filename.dir_sep ^ filename in
        let reader = Pervasives.open_in file in
        read_line reader (S.empty)

      (** takes a directory and directory_handl and a dictionary,
          and adds each filename as a key in that maps to set of words 
          in the file *)
      let rec dir_reader dir hdl dict =
        match Unix.readdir hdl with
        | exception End_of_file -> Unix.closedir hdl; dict
        | s -> 
          let regex = Str.regexp ".*\\.txt" in 
          let is_txt = Str.string_match regex s 0 in
          if is_txt then
            let new_dict = D.insert s (file_to_words dir s) dict in
            dir_reader dir hdl new_dict
          else dir_reader dir hdl dict

      (** [index_of_dir d] is an index of the files in [d].  Only files whose
          names end in [.txt] are indexed.  Only [d] itself, not any
          of its subdirectories, is indexed.
          Raises: Not_found if [d] is not a valid directory. *)
      let index_of_dir d =
        match Unix.opendir d with
        | exception Unix.Unix_error (_,_,_) -> raise Not_found
        | h -> 
          dir_reader d h (D.empty)

      (** [words idx] is a set-like list of the words indexed in [idx]. *)
      let words idx = 
        let f key value init = S.union value init in
        let s = D.fold f (S.empty) idx in
        S.to_list s

      (** inserts a key value pair to an association list*)
      let rec insert_pair k v init acc =
        match init with
        | [] -> acc @ [(k, [v])]
        | (k2, v2)::t -> if k = k2 then acc @ (k, v::v2)::t
          else insert_pair k v t ((k2,v2)::acc)

      (** inserts the words and file names to an association list that 
          has filename as key and list of words as values*)
      let rec insert_file_words filename words init =
        match words with
        | [] -> init
        | h::t  -> let new_init = insert_pair h filename init [] in
          insert_file_words filename t new_init

      (** helper function that takes list of dictionary and outputs
          a list that represent index *)
      let rec list_maker dict_list init =
        match dict_list with
        | [] -> init
        | (k,v)::t -> let new_init = insert_file_words k v init in
          list_maker t new_init

      (** [to_list idx] is a representation of [idx] as an association
          list.  Order in the list is irrelevant.  The keys in the list
          must be equivalent to [words idx], ignoring order.  The value 
          corresponding to a key is a set-like list of the files in which 
          that word appears. *)
      let to_list idx =
        let dict_list = D.to_list idx in
        let f (key, value) = (key, S.to_list value) in
        let full_list = List.map f dict_list in
        list_maker full_list []

      (** [precond andors] checks if [ands] and [ors] satisfy the precondition:
          [ands] and [ors] are not empty*)
      let precond andor = 
        match andor with  
        | [] -> failwith "[ands] and [ors] cannot be empty"
        | h::t -> andor   

      (** [find_filenames idx word] is a set of filenames that contains the [word]*)
      let find_filenames idx word = 
        let filter = fun x y acc -> if S.member word y then (S.insert x acc) 
          else acc in  D.fold filter S.empty idx 

      (** [files_ands idx orsnots acc] is a set of filenames that contain one 
          or more words in [ors] and [nots]*)
      let rec files_orsnots idx orsnots acc = 
        match orsnots with 
        | [] -> acc
        | h::t -> files_orsnots idx t (S.union (find_filenames idx h) acc)

      (** [files_ands idx ands acc] is a set of filenames that contain all words 
          in [ands]*)
      let rec files_ands idx ands acc = 
        match ands with 
        | [] -> acc
        | h::t -> files_ands idx t (S.intersect (find_filenames idx h) acc) 

      (** [ands_acc idx] is a set of all filenames in [idx]*)
      let ands_acc (idx:idx) = 
        let filter = fun x y acc -> (S.insert x acc) in D.fold filter S.empty idx 

      (** [or_not] is a set-like list of the files that contain
          any of the words in [ors] and none of the words in [nots].
          Requires: [ors] is not empty.*)
      let or_not idx ors nots =
        let or_files = files_orsnots idx (precond ors) S.empty in 
        let not_files = files_orsnots idx nots S.empty in 
        (let filter = fun h acc -> S.remove h acc in 
         S.fold filter or_files not_files ) |> S.to_list

      (** [and_not idx ands nots] is a set-like list of the files that contain
          all of the words in [ands] and none of the words in [nots].
          Requires: [ands] is not empty. *)
      let and_not idx ands nots =
        let and_files = files_ands idx (precond ands) (ands_acc idx) in 
        let not_files = files_orsnots idx nots S.empty in 
        (let filter = fun h acc -> S.remove h acc in 
         S.fold filter and_files not_files ) |> S.to_list

      (** [format] is a printing function suitable for use
          with the toplevel's [#install_printer] directive.
          It outputs a textual representation of an index
          on the given formatter. *)
      let format fmt idx =
        (*BISECT-IGNORE*) D.format fmt idx
    end