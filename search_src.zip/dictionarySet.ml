open Dictionary

module type ElementSig = sig
  type t
  include Dictionary.KeySig with type t := t
end

module type Set = sig
  module Elt : ElementSig
  type elt = Elt.t
  type t
  val rep_ok : t  -> t
  val empty : t
  val is_empty : t -> bool
  val size : t -> int
  val insert : elt -> t -> t
  val member : elt -> t -> bool
  val remove : elt -> t -> t
  val union : t -> t -> t
  val intersect : t -> t -> t
  val difference : t -> t -> t
  val choose : t -> elt option
  val fold : (elt -> 'acc -> 'acc) -> 'acc -> t -> 'acc
  val to_list : t -> elt list
  val format : Format.formatter -> t -> unit
end

module UnitVal : (ValueSig with type t = unit) = struct
  type t = unit
  let format fmt u = ()
end

module Make =
  functor (E : ElementSig) -> functor (DM : DictionaryMaker) ->
  struct

    module Elt = E
    type elt = Elt.t

    (* AF: A DictionarySet [(k1, ()); (k2, ()); (k3, ()); ...; (kn, ())] 
       represents the smallest set contains elements {k1, k2, k3, ..., kn}.
     * RI: The set contains no duplicates.*)   

    module DSet = DM(Elt)(UnitVal)

    (** [t] is the type of sets. *)
    type t = DSet.t

    (** [rep_ok s] returns [s] if [s] satisfies its representation
        invariants.  It's unusual for a data abstraction to
        expose this function to its clients, but we do so here
        to ensure that you implement it.
        Raises: [Failure] with an unspecified error message
          if [s] does not satisfy its representation invariants. *)
    let rep_ok s = (*BISECT-IGNORE*) DSet.rep_ok s

    (** [empty] is the empty set. *)
    let empty = DSet.empty

    (** [is_empty s] is [true] iff [s] is empty. *)
    let is_empty s = DSet.is_empty s

    (** [size s] is the number of elements in [s]. *
        [size empty] is [0]. *)
    let size s = DSet.size s

    (** [insert x s] is a set containing all the elements of
        [s] as well as element [x]. *)
    let insert x s = DSet.insert x () s

    (** [member x s] is [true] iff [x] is an element of [s]. *)
    let member x s = DSet.member x s

    (** [remove x s] contains all the elements of [s] except
         [x].  If [x] is not an element of [s], then
         [remove] returns a set with the same elements as [s]. *)
    let remove x s = DSet.remove x s

    (** [to_list s] is a list containing the same
        elements as [s].  The order of elements in the list is
        in order from the least set element to the greatest. *)
    let to_list s = List.map fst (DSet.to_list s)  

    (** [choose s] is [Some x], where [x] is an unspecified
        element of [s].  If [s] is empty, then [choose s] is [None]. *)
    let choose s =
      match (DSet.choose s) with 
      | None -> None 
      | Some (k,v) -> Some k 

    (** [fold f init s] is [f xn (f ... (f x1 init) ...)],
        if [s] contains [x1]..[xn].  Elements are processed
        in order from least to greatest, where [x1] is the
        least element and [xn] is the greatest. *)
    let fold f init s =
      let new_f = fun x _ y -> f x y in
      DSet.fold new_f init s 

    (** [union] is set union, that is, [union s1 s2] contains
        exactly those elements that are elements of [s1]
        or elements of [s2]. *)
    let union s1 s2 =
      let f = fun x acc -> insert x acc in 
      (fold f s1 s2)  

    (** [intersect] is set intersection, that is, [intersect s1 s2]
        contains exactly those elements that are elements of [s1]
        and elements of [s2]. *)
    let intersect s1 s2 =
      let f = fun x acc -> if (member x s2) then insert x acc else acc 
      in (fold f empty s1)

    (** [difference s1 s2] calculates set difference that is s1 - s2
        so that for example set difference of {a,b} and {a,c} is {b,c}. *)
    let difference s1 s2 =
      let u = union s1 s2 in
      let i = intersect s1 s2 in
      let f = fun x acc -> if not (member x i) then insert x acc else acc
      in (fold f empty u)

    (** [format] is a printing function suitable for use
        with the toplevel's [#install_printer] directive.
        It outputs a textual representation of a set
        on the given formatter. *)
    let format fmt d = (*BISECT-IGNORE*) DSet.format fmt d

  end
