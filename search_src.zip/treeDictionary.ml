open Dictionary

module Make
  = functor (K : KeySig) -> functor (V : ValueSig) ->
  struct
    module Key = K
    module Value = V
    type key = K.t
    type value = V.t

    (* AF: A tree dictionary is a red black tree whose members are either a 
       node or leaf. A Node (color, (key,value), left, right) represents tree member
       with a color R, B, or BB, a binding of a key to a value, and a left and right 
       subtree. A Leaf only has color.      
     * RI: 
       1. For a tree ((k,v), left, right), all the keys in the left tree are lesser
       than k, and all the keys in the right tree are greater than k. 
       2. There are no two adjacent red nodes along any path.
       3. Every path from the root to a leaf has the same number of black nodes. 
       This number is called the black height (BH) of the tree.*)

    (** [color] is the type of color of the nodes in a tree dictionary.*)
    type color =  R | B | BB

    (** [t] is the type of tree dictionary.*)
    type t = Node of color * (key * value) * t * t
           |Leaf of color

    (** [check_lower_bound bound bk] checks if the current key or current lower
        bound key is the lowest key. *) 
    let check_lower_bound bound bk =
      (*BISECT-IGNORE-BEGIN*)

      match bound with
      | None -> true
      | Some(k) -> K.compare k bk = LT || K.compare k bk = EQ
    (*BISECT-IGNORE-END*)


    (** [check_upper_bound bound bk] checks if the current key or current upper
        bound key is the upper bound key. *) 
    let check_upper_bound bound bk =
      (*BISECT-IGNORE-BEGIN*)

      match bound with
      | None -> true
      | Some(k) -> K.compare k bk = GT || K.compare k bk = EQ
    (*BISECT-IGNORE-END*)

    (** [tree_check d acc upper lower] returns true if [d] satisfies the RI of BST:
        For a tree (n, left, right), all the keys in the left tree are lesser
        than n, and all the keys in the right tree are greater than n. *)
    let rec tree_check d (lower: Key.t option) (upper: Key.t option) = 
      (*BISECT-IGNORE-BEGIN*)

      match d with
      | Leaf(_) -> true
      | Node(_, (key,v), left, right) -> 
        if (check_upper_bound upper key) && (check_lower_bound lower key)
        then tree_check left (lower) (Some(key)) 
             && tree_check right (Some(key)) upper
        else
          false
    (*BISECT-IGNORE-END*)


    (** [red_check d acc] returns true if [d] satisfies the RI of RBT part 1:
          There are no two adjacent red nodes along any path. *)
    let rec red_check d acc =
      (*BISECT-IGNORE-BEGIN*)

      if acc = false then false else 
        match d with 
        | Leaf c -> true 
        | Node (color, (_, _), left, right) -> 
          match (left, right) with 
          |(Leaf _, Leaf _) -> true  
          (* if the node color is R, check if the adjacent node on path is R. 
             if true, fails RI, else check the rest of the tree *)
          |(Leaf _, (Node (right_c,(_,_),_,_) as r)) -> 
            if (color = R && color = right_c) then false else red_check r true 
          |((Node (left_c,(_,_),_,_) as l), Leaf _) -> 
            if (color = R && color = left_c) then false else red_check l true 
          |((Node (left_c,(_,_),_,_) as l), (Node (right_c,(_,_),_,_) as r)) -> 
            if (color = R && (color = left_c || color = right_c)) 
            then false else ((red_check l true) && (red_check r true)) 
    (*BISECT-IGNORE-END*)


    (** [exp_bh d] finds the black_height of leftmost path of the tree *)
    let rec exp_bh d = 
      (*BISECT-IGNORE-BEGIN*)
      match d with 
      | Leaf c -> 0 
      | Node (color, (_, _), left, right) -> 
        if (color = B) then 1 + exp_bh left else exp_bh left
    (*BISECT-IGNORE-END*)


    (** [black_height d] finds every black height, which is number of black nodes 
        from root to leaf, to the expect black height of leftmost path. 
        This function is created to satisfy RBT part 2:   
        Every path from the root to a leaf has the same number of black nodes. 
        This number is called the black height (BH) of the tree. *)  
    let rec black_height d h acc = 
      (*BISECT-IGNORE-BEGIN*)
      match d with 
      | Leaf c -> (h = acc) 
      | Node (color, (_, _), left, right) -> if color = B then 
          (black_height left h (acc+1)) && (black_height right h (acc+1))
        else (black_height left h acc) && (black_height right h acc)  
    (*BISECT-IGNORE-END*)


    (**[debug] is a helper function to enable/disable [rep_ok d]. *)
    let debug = false

    (** [rep_ok d] returns d if d satisfies the RI. 
        Raise: [Failure] if d violates the RI.*)
    let rep_ok d =
      (*BISECT-IGNORE-BEGIN*)
      if not debug then d else
      if (tree_check d None None) && red_check d true 
         && black_height d (exp_bh d) 0 
      then d else 
        failwith "This tree does not satisfy the RI for treeDictionary."
    (*BISECT-IGNORE-END*)

    (** [empty] is an empty tree *)
    let empty = Leaf (B) 

    (** [is_empty d] is [true] iff the tree [d] is empty. *)
    let is_empty d = (d = empty) 


    (** [size d] is the number of nodes in tree [d]. *)
    let size d =
      let rec size_acc d acc = 
        match d with 
        | Leaf c -> acc 
        | Node (_, _, left, right)-> 1 + (size_acc left (size_acc right acc)) 
      in size_acc d 0  

    (** [balance] function taken from the textbook. [balance] takes a tree [d] 
        and adjusts the tree so the RI is satisfied. *)
    let balance tree = 
      match tree with
      | Node(B, z, Node (R, y, Node (R, x, a, b), c), d)
      | Node(B, z, Node (R, x, a, Node (R, y, b, c)), d)
      | Node(B, x, a, Node (R, z, Node (R, y, b, c), d))
      | Node(B, x, a, Node (R, y, b, Node (R, z, c, d))) ->
        Node (R, y, Node (B, x, a, b), Node (B, z, c, d))
      (*the pattern below is for remove*)
      | Node(BB, z, Node(R, x, a, Node(R, y, b, c)), d)
      | Node(BB, x, a, Node(R, z, Node(R, y, b, c), d))
        -> Node(B, y, Node(B, x, a, b), Node(B, z, c, d))

      | _ -> tree

    (** [insert k v d] function variation from the textbook. [insert] is a [d] 
        that satisfies the RI with a new node that binds a k to a v. 
        [insert k v d] is [d] with [k] bound to [v]. If [k] was already bound, 
        its previous value is replaced with [v].  *)
    let insert k v d =
      let rec ins d = 
        match d with 
        | Leaf c -> Node (R, (k,v), Leaf c, Leaf c) (* leaf -> red *)
        | Node (color, (bk,bv), a, b) ->
          if Key.compare k bk = LT then balance (Node(color, (bk,bv), ins a, b))
          else if Key.compare k bk = GT then balance (Node(color, (bk,bv), a, ins b))
          else balance (Node(color, (k,v), a, b)) (* replace bk, kv with k,v *) in
      match ins d with
      | Node (_, (bk,bv), a, b) -> Node (B, (bk,bv), a, b) (* root -> black *)
      | Leaf c -> (* guaranteed to be nonempty *)
        failwith "RBT cannot be empty"


    (** [find k d] is [Some v] if [k] is bound to [v] in [d]; or
        if [k] is not bound, then it is [None]. *)
    let rec find k d = 
      match d with 
      | Leaf c -> None 
      | Node (_, (key, value), left, right) -> 
        if Key.compare k key = LT then find k left 
        else if Key.compare k key = GT then find k right 
        else Some value 

    (*-------------- remove functions start here ------------*)

    (** [isB] checks if the node of the tree is black. *)
    let isB = function
      | Leaf(B) -> true
      | Node(B, _, _, _) -> true
      | _ -> false

    (** [isBB] checks if the node of the tree is double black. *)
    let isBB = function
      | Leaf(BB) -> true
      | Node(BB, _, _, _) -> true
      | _ -> false

    (**[downgrade tree] takes a double black or black node and downgrades
     * it to regular black node.
     *Raises: [Failure] if given a red node*)
    let downgrade = function
      | Leaf(BB) -> Leaf(B)
      | Node(BB, x, a, b) -> Node(B, x, a, b)
      | Node(R, _, _, _) -> failwith "Error: attempt to downgrade a red node"
      | n -> n

    (** [rotate tree] rotates the tree as per detailed in the paper. *)
    let rotate tree = match tree with
      | Node(R, y, a, Node(B, z, c, d)) when (isBB a)
        -> balance (Node(B, z, Node(R, y, (downgrade a), c), d))
      | Node(R, y, Node(B, x, a, b), c) when (isBB c)
        -> balance (Node(B, x, a, Node(R, y, b, (downgrade c))))
      | Node(B, y, a, Node(B, z, c, d)) when (isBB a)
        -> balance (Node(BB, z, Node(R, y, (downgrade a), c) ,d))
      | Node(B, y, Node(B, x, a, b), c) when (isBB c)
        -> balance (Node(BB, x, a, Node(R, y, b, (downgrade c))))
      | Node(B, x, a, Node(R, z, Node(B, y, c, d), e)) when (isBB a)
        -> Node(B, z, balance(Node(B, y, Node(R, x, (downgrade a), c), d)), e)
      | Node(B, y, Node(R, w, a, Node(B, x, b, c)), d) when (isBB d)
        -> Node(B, w, a, balance(Node(B, x, b, Node(R, y, c, downgrade(d)))))
      | _ -> tree

    (**[min_delete tree] takes a subtree and return the in-order successor 
     * with the appropriate new color for the node*)
    let rec min_delete = function
      | Leaf(c) -> failwith "Error: attempt to delete a from empty tree"
      | Node(R, x, Leaf(B), Leaf(B)) -> (x, Leaf(B))
      | Node(B, x, Leaf(B), Leaf(B)) -> (x, Leaf(BB))
      | Node(B, x, Leaf(B), Node(R, y, a, b)) -> (x, Node(B, y, a, b))
      | Node(c, x, a, b) -> let (v, a') = min_delete a in
        (v, rotate(Node(c, v, a', b)))

    (** [del k] deletes key k from the tree*)
    let rec del k = function
      | Leaf(R) | Leaf(BB) 
        -> failwith "Error: recieved red or double black leaf for delete"
      | Leaf(B) -> Leaf(B) (*delete from empty tree is empty tree*)
      | Node(R, x, Leaf(B), Leaf(B)) when (K.compare (fst x) k) = EQ
        -> Leaf(B)
      | Node(B, x, Node(R, y, a, b), Leaf(B)) when (K.compare (fst x) k) = EQ
        -> Node(B, y, a, b)
      | Node(B, x, Leaf(B), Leaf(B)) when (K.compare (fst x) k) = EQ
        -> Leaf(BB)
      | Node(c, x, a, b) -> match K.compare k (fst x) with
        | LT -> rotate (Node(c, x, del k a, b))
        | EQ -> let (x', b') = min_delete b in
          rotate (Node(c, x', a, b'))
        | GT -> rotate (Node(c, x, a, del k b))

    (** [redden tree] reddens the black node under specific conditions.*)
    let redden tree = match tree with
      | Node(B, x, a, b) when (isB a && isB b) -> Node(R, x, a, b)
      | _ -> tree

    (** [remove k d] removes a binding of [k] from the tree [d] *)
    let remove k d =
      del k (redden d)

    (*------------- remove functions end here    ------------*)

    (** [member k d] is [true] iff [k] is bound in [d]. *)
    let rec member k d =
      match (d) with 
      |Leaf n -> false
      |Node (_, (key, _), left, right) -> 
        if (Key.compare k key = EQ) then true
        else if (Key.compare k key = LT) then  member k left 
        else  member k right

    (** [choose d] is [Some (k,v)], where [k] is bound to [v]
            in [d].  It is unspecified which binding of [d] is
            returned.  If [d] is empty, then [choose d] is [None]. *)
    let choose d =
      match d with
      | Leaf n -> None
      | Node (_, binding, left, right) -> Some binding

    (** [to_list d] is an association list containing the same
        bindings as [d].  The  elements in the list are
        in order from the least key to the greatest. *)
    let to_list d =
      (** [unordered_list d acc] returns an unordered list of all bindings in d.
          It is tail-recursive.*)
      let rec unordered_list d acc = 
        match d with
        | Leaf n -> acc
        | Node (_, binding, left, right) -> 
          unordered_list left ((unordered_list right []) @ (binding::acc)) in
      let sort_binding a b =
        let ((ka, _), (kb, _)) = (a,b) in
        match (Key.compare ka kb) with
        |EQ -> 0 |GT -> 1 |LT -> -1 in
      List.sort sort_binding (unordered_list (d) []) 

    (** [fold f acc d] is [f kn vn (f ... (f k1 v1 acc) ...)],
            if [d] binds [ki] to [vi].  Bindings are processed
            in order from least to greatest, where [k1] is the
            least key and [kn] is the greatest. *)
    let fold f acc d =
      let rec fold_rec f acc lst = (**takes a list instead of t*)
        match lst with 
        | [] -> acc
        | (k,v)::t -> fold_rec f (f k v acc) t in
      d  |> to_list |> fold_rec f acc 

    (** [format_assoc_list fmt_key fmt_val fmt lst] formats an association 
        list [lst] as a dictionary.  The [fmt_key] and [fmt_val] arguments
        are formatters for the key and value types, respectively.  The
        [fmt] argument is where to put the formatted output. 
        It is copied from the source code of A4.*)
    let format_assoc_list format_key format_val fmt lst =
      (*BISECT-IGNORE-BEGIN*)
      Format.fprintf fmt "[";
      List.iter (fun (k,v) -> Format.fprintf fmt "%a -> %a; "
                    format_key k format_val v) lst;
      Format.fprintf fmt "]"
    (*BISECT-IGNORE-END*)


    (** [format] is a printing function suitable for use
        with the toplevel's [#install_printer] directive.
        It outputs a textual representation of a dictionary
        on the given formatter. *)
    let format fmt d =
      (*BISECT-IGNORE-BEGIN*)
      d |> to_list |> format_assoc_list K.format V.format fmt 
      (*BISECT-IGNORE-END*)


  end
