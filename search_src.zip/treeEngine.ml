(* Note that there is nothing you need to complete in this file. *)

open Dictionary

module StringKey
  : KeySig with type t = string
=
struct
  type t = string
  let compare s1 s2 =
    match Pervasives.compare s1 s2 with
    | x when x < 0 -> LT
    | x when x > 0 -> GT
    | _ -> EQ
  let format fmt s =
    (*BISECT-IGNORE-BEGIN*)

    Format.fprintf fmt "\"%s\"" s
    (*BISECT-IGNORE-END*)

end

module S = DictionarySet.Make(StringKey)(TreeDictionary.Make)
module D = TreeDictionary.Make(StringKey)(S)
module TreeEngine = Engine.Make(S)(D)
