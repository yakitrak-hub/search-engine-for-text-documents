(* Note that there is nothing you need to complete in this file. 
   All the work you need to do for engines is in [engine.ml]. *)

open Dictionary

module StringKey
  : KeySig with type t = string
=
struct
  type t = string
  let compare s1 s2 =
    match Pervasives.compare s1 s2 with
    | x when x < 0 -> LT
    | x when x > 0 -> GT
    | _ -> EQ
  let format fmt s =
    Format.fprintf fmt "\"%s\"" s
end

module S = DictionarySet.Make(StringKey)(ListDictionary.Make)
module D = ListDictionary.Make(StringKey)(S)
module ListEngine = Engine.Make(S)(D)
