(* All the code in this file is provided just to help you.
   You can change it or ignore it as you see fit. *)
open Dictionary
(** [i -- j] is the list of integers from [i] to [j], inclusive.
    Tail recursive. *)
let (--) (i : int) (j : int) : int list =
  let rec from i j l =
    if i>j then l
    else from i (j-1) (j::l)
  in from i j []

(** [rnd_lst n] is a list of [n] random integers. *)
let rnd_list (n : int) : int list =
  QCheck.Gen.(generate ~n int)

(** [rnd_sort_lst n] is a list of [n] random integers in ascending order. *)
let rnd_sort_list (n : int) : int list =
  QCheck.Gen.(generate ~n int) |> List.sort Pervasives.compare

(** [shuffle lst] is a random permutation of [lst]. *)
let shuffle (lst : 'a list) : 'a list =
  QCheck.Gen.(generate1 (shuffle_l lst))

(** [time f] is the time in seconds it takes to run [f ()]. *)
let time (f : unit -> unit) : float =
  let t = Unix.gettimeofday () in
  ignore (f ());
  Unix.gettimeofday () -. t 

(* Create Int element*)
module Int = struct
  type t = int
  let compare x y =
    match Pervasives.compare x y with
    | x when x<0 -> LT
    | 0 -> EQ
    | _ -> GT
  let format fmt x =
    (*BISECT-IGNORE-BEGIN*)Format.fprintf fmt "%d" x (*BISECT-IGNORE-END*)
end;;

(* Create List set containing integers*)
module IntDictSet = DictionarySet.Make(Int)(ListDictionary.Make)

let d_empty = IntDictSet.empty 
let d_insert = IntDictSet.insert
let d_member = IntDictSet.member
let d_remove = IntDictSet.remove

(* Create Tree set containing integers*)
module IntTreeSet = DictionarySet.Make(Int)(TreeDictionary.Make)

let t_empty = IntTreeSet.empty 
let t_insert = IntTreeSet.insert
let t_member = IntTreeSet.member
let t_remove = IntTreeSet.remove

(** [compare_floats x y] is a comparison function that returns 0 
    if x is equal to y, a negative integer if x is less than y, 
    and a positive integer if x is greater than y. *)
let compare_floats x y =
  if x = y then 0 else 
    (if x > y then 1 else -1)

(** [getmedian lst] returns the median of the elements in a list. *)
let getmedian lst = 
  match List.sort compare_floats lst with 
  | a::b::c -> b
  | _ -> failwith "No median exists"

(**[dict_insert lst set] inserts the elements in the list [lst] into the 
   list set *)
let rec dict_insert lst set = 
  match lst with 
  | [] -> set 
  | h::t -> dict_insert t (d_insert h set)

(** [dict_member lst set] returns the set if the elements of list [lst]
    are the same as in the set. If not then it raises exception *)
let rec dict_member lst set =   
  match lst with 
  | [] -> set 
  | h::t -> if d_member h set then dict_member t set else failwith "member failure"

(** [dict_remover lst set] removes all the elements in set that correspond
    to list [lst].*)
let rec dict_remover lst set = 
  match lst with
  | []-> set
  | h::t -> dict_remover t (d_remove h set)

(** [tester lst] insert the elements in lst into an empty list set, 
    then it does membership tests for the elements in lst compared to 
    the new set 4 times (with the list [lst] shuffled each time) and finally
    it shuffles the list [lst] again and uses that list to remove the elements
    in the set that correspond to lst.*)
let tester lst =
  let set1 = dict_insert lst d_empty in 
  let set2 = dict_member lst set1 in
  let set3 = dict_member (shuffle lst) set2 in 
  let set4 = dict_member (shuffle lst) set3 in 
  let set5 = dict_member (shuffle lst) set4 in 
  let set6 = dict_remover (shuffle lst) set5 in ()


let rl1a  =  rnd_list 1000
let rl2a  =  rnd_list 2000
let rl3a  =  rnd_list 3000
let rl4a  =  rnd_list 4000
let rl5a  =  rnd_list 5000
let rl6a  =  rnd_list 6000
let rl7a  =  rnd_list 7000
let rl8a  =  rnd_list 8000
let rl9a  =  rnd_list 9000
let rl10a  =  rnd_list 10000


let rl1b  =  rnd_list 1000
let rl2b =  rnd_list 2000
let rl3b  =  rnd_list 3000
let rl4b  =  rnd_list 4000
let rl5b =  rnd_list 5000
let rl6b  =  rnd_list 6000
let rl7b  =  rnd_list 7000
let rl8b  =  rnd_list 8000
let rl9b  =  rnd_list 9000
let rl10b  =  rnd_list 10000

let rl1c  =  rnd_list 1000
let rl2c  =  rnd_list 2000
let rl3c  =  rnd_list 3000
let rl4c  =  rnd_list 4000
let rl5c  =  rnd_list 5000
let rl6c =  rnd_list 6000
let rl7c  =  rnd_list 7000
let rl8c  =  rnd_list 8000
let rl9c  =  rnd_list 9000
let rl10c  =  rnd_list 10000


let dtr1a = time (fun() -> tester rl1a)
let dtr1b = time (fun() -> tester rl1b)
let dtr1c = time (fun() -> tester rl1c)
let drlist_1000 = [dtr1a;dtr1b;dtr1c]
let drmedian_1000 = getmedian drlist_1000



let dtr2a = time (fun() -> tester rl2a)
let dtr2b = time (fun() -> tester rl2b)
let dtr2c = time (fun() -> tester rl2c)
let drlist_2000 = [dtr2a;dtr2b;dtr2c]
let drmedian_2000 = getmedian drlist_2000


let dtr3a = time (fun() -> tester rl3a)
let dtr3b = time (fun() -> tester rl3b)
let dtr3c = time (fun() -> tester rl3c)
let drlist_3000 = [dtr3a;dtr3b;dtr3c]
let drmedian_3000 = getmedian drlist_3000

let dtr4a = time (fun() -> tester rl4a)
let dtr4b = time (fun() -> tester rl4b)
let dtr4c = time (fun() -> tester rl4c)
let drlist_4000 = [dtr4a;dtr4b;dtr4c]
let drmedian_4000 = getmedian drlist_4000

let dtr5a = time (fun() -> tester rl5a)
let dtr5b = time (fun() -> tester rl5b)
let dtr5c = time (fun() -> tester rl5c)
let drlist_5000 = [dtr5a;dtr5b;dtr5c]
let drmedian_5000 = getmedian drlist_5000



let dtr6a = time (fun() -> tester rl6a)
let dtr6b = time (fun() -> tester rl6b)
let dtr6c = time (fun() -> tester rl6c)
let drlist_6000 = [dtr6a;dtr6b;dtr6c]
let drmedian_6000 = getmedian drlist_6000

let dtr7a = time (fun() -> tester rl7a)
let dtr7b = time (fun() -> tester rl7b)
let dtr7c = time (fun() -> tester rl7c)
let drlist_7000 = [dtr7a;dtr7b;dtr7c]
let drmedian_7000 = getmedian drlist_7000

let dtr8a = time (fun() -> tester rl8a)
let dtr8b = time (fun() -> tester rl8b)
let dtr8c = time (fun() -> tester rl8c)
let drlist_8000 = [dtr8a;dtr8b;dtr8c]
let drmedian_8000 = getmedian drlist_8000

let dtr9a = time (fun() -> tester rl9a)
let dtr9b = time (fun() -> tester rl9b)
let dtr9c = time (fun() -> tester rl9c)
let drlist_9000 = [dtr9a;dtr9b;dtr9c]
let drmedian_9000 = getmedian drlist_9000

let dtr10a = time (fun() -> tester rl10a)
let dtr10b = time (fun() -> tester rl10b)
let dtr10c = time (fun() -> tester rl10c)
let drlist_10000 = [dtr10a;dtr10b;dtr10c]
let drmedian_10000 = getmedian drlist_10000

let l1a  =  rnd_sort_list 1000
let l2a  =  rnd_sort_list 2000
let l3a  =  rnd_sort_list 3000
let l4a  =  rnd_sort_list 4000
let l5a  =  rnd_sort_list 5000
let l6a  =  rnd_sort_list 6000
let l7a  =  rnd_sort_list 7000
let l8a  =  rnd_sort_list 8000
let l9a  =  rnd_sort_list 9000
let l10a  =  rnd_sort_list 10000

let l1b  =  rnd_sort_list 1000
let l2b  =  rnd_sort_list 2000
let l3b  =  rnd_sort_list 3000
let l4b  =  rnd_sort_list 4000
let l5b  =  rnd_sort_list 5000
let l6b  =  rnd_sort_list 6000
let l7b  =  rnd_sort_list 7000
let l8b  =  rnd_sort_list 8000
let l9b  =  rnd_sort_list 9000
let l10b  =  rnd_sort_list 10000

let l1c  =  rnd_sort_list 1000
let l2c  =  rnd_sort_list 2000
let l3c  =  rnd_sort_list 3000
let l4c  =  rnd_sort_list 4000
let l5c  =  rnd_sort_list 5000
let l6c  =  rnd_sort_list 6000
let l7c  =  rnd_sort_list 7000
let l8c  =  rnd_sort_list 8000
let l9c  =  rnd_sort_list 9000
let l10c  =  rnd_sort_list 10000

let dt1a = time (fun() -> tester l1a)
let dt1b = time (fun() -> tester l1b)
let dt1c = time (fun() -> tester l1c)
let dlist_1000 = [dt1a;dt1b;dt1c]
let dmedian_1000 = getmedian dlist_1000

let dt2a = time (fun() -> tester l2a)
let dt2b = time (fun() -> tester l2b)
let dt2c = time (fun() -> tester l2c)
let dlist_2000 = [dt2a;dt2b;dt2c]
let dmedian_2000 = getmedian dlist_2000

let dt3a = time (fun() -> tester l3a)
let dt3b = time (fun() -> tester l3b)
let dt3c = time (fun() -> tester l3c)
let dlist_3000 = [dt3a;dt3b;dt3c]
let dmedian_3000 = getmedian dlist_3000

let dt4a = time (fun() -> tester l4a)
let dt4b = time (fun() -> tester l4b)
let dt4c = time (fun() -> tester l4c)
let dlist_4000 = [dt4a;dt4b;dt4c]
let dmedian_4000 = getmedian dlist_4000

let dt5a = time (fun() -> tester l5a)
let dt5b = time (fun() -> tester l5b)
let dt5c = time (fun() -> tester l5c)
let dlist_5000 = [dt5a;dt5b;dt5c]
let dmedian_5000 = getmedian dlist_5000

let dt6a = time (fun() -> tester l6a)
let dt6b = time (fun() -> tester l6b)
let dt6c = time (fun() -> tester l6c)
let dlist_6000 = [dt6a;dt6b;dt6c]
let dmedian_6000 = getmedian dlist_6000

let dt7a = time (fun() -> tester l7a)
let dt7b = time (fun() -> tester l7b)
let dt7c = time (fun() -> tester l7c)
let dlist_7000 = [dt7a;dt7b;dt7c]
let dmedian_7000 = getmedian dlist_7000

let dt8a = time (fun() -> tester l8a)
let dt8b = time (fun() -> tester l8b)
let dt8c = time (fun() -> tester l8c)
let dlist_8000 = [dt8a;dt8b;dt8c]
let dmedian_8000 = getmedian dlist_8000

let dt9a = time (fun() -> tester l9a)
let dt9b = time (fun() -> tester l9b)
let dt9c = time (fun() -> tester l9c)
let dlist_9000 = [dt9a;dt9b;dt9c]
let dmedian_9000 = getmedian dlist_9000

let dt10a = time (fun() -> tester l10a)
let dt10b = time (fun() -> tester l10b)
let dt10c = time (fun() -> tester l10c)
let dlist_10000 = [dt10a;dt10b;dt10c]
let dmedian_10000 = getmedian dlist_10000

(**[tree_insert lst set] inserts the elements in the list [lst] into the 
   tree set *)
let rec tree_insert lst set = 
  match lst with 
  | [] -> set 
  | h::t -> tree_insert t (t_insert h set)

(** [tree_member lst set] returns the set if the elements of list [lst]
    are the same as in the set. If not then it raises exception *)
let rec tree_member lst set =   
  match lst with 
  | [] -> set 
  | h::t -> if t_member h set then tree_member t set else failwith "member failure"

(** [tree_remover lst set] removes all the elements in set that correspond
    to list [lst].*)
let rec tree_remover lst set = 
  match lst with
  | []-> set
  | h::t -> tree_remover t (t_remove h set)

(** [tree_tester lst] insert the elements in lst into an empty tree set, 
    then it does membership tests for the elements in lst compared to 
    the new set 4 times (with the list [lst] shuffled each time) and finally
    it shuffles the list [lst] again and uses that list to remove the elements
    in the set that correspond to lst.*)
let tree_tester lst =
  let set1 = tree_insert lst t_empty in 
  let set2 = tree_member lst set1 in
  let set3 = tree_member (shuffle lst) set2 in 
  let set4 = tree_member (shuffle lst) set3 in 
  let set5 = tree_member (shuffle lst) set4 in 
  let set6 = tree_remover (shuffle lst) set5 in ()


let rt1a  =  rnd_list 100000
let rt2a  =  rnd_list 200000
let rt3a  =  rnd_list 300000
let rt4a  =  rnd_list 400000
let rt5a  =  rnd_list 500000
let rt6a  =  rnd_list 600000
let rt7a  =  rnd_list 700000
let rt8a  =  rnd_list 800000
let rt9a  =  rnd_list 900000
let rt10a  =  rnd_list 1000000

let rt1b  =  rnd_list 100000
let rt2b  =  rnd_list 200000
let rt3b  =  rnd_list 300000
let rt4b  =  rnd_list 400000
let rt5b  =  rnd_list 500000
let rt6b  =  rnd_list 600000
let rt7b  =  rnd_list 700000
let rt8b  =  rnd_list 800000
let rt9b  =  rnd_list 900000
let rt10b  =  rnd_list 1000000

let rt1c  =  rnd_list 100000
let rt2c  =  rnd_list 200000
let rt3c  =  rnd_list 300000
let rt4c  =  rnd_list 400000
let rt5c  =  rnd_list 500000
let rt6c  =  rnd_list 600000
let rt7c  =  rnd_list 700000
let rt8c  =  rnd_list 800000
let rt9c  =  rnd_list 900000
let rt10c  =  rnd_list 1000000


let ttr1a = time (fun() -> tree_tester rt1a)
let ttr1b = time (fun() -> tree_tester rt1b)
let ttr1c = time (fun() -> tree_tester rt1c)
let trlist_100000 = [ttr1a;ttr1b;ttr1c]
let trmedian_100000 = getmedian trlist_100000

let ttr2a = time (fun() -> tree_tester rt2a)
let ttr2b = time (fun() -> tree_tester rt2b)
let ttr2c = time (fun() -> tree_tester rt2c)
let trlist_200000 = [ttr2a;ttr2b;ttr2c]
let trmedian_200000 = getmedian trlist_200000

let ttr3a = time (fun() -> tree_tester rt3a)
let ttr3b = time (fun() -> tree_tester rt3b)
let ttr3c = time (fun() -> tree_tester rt3c)
let trlist_300000 = [ttr3a;ttr3b;ttr3c]
let trmedian_300000 = getmedian trlist_300000

let ttr4a = time (fun() -> tree_tester rt4a)
let ttr4b = time (fun() -> tree_tester rt4b)
let ttr4c = time (fun() -> tree_tester rt4c)
let trlist_400000 = [ttr4a;ttr4b;ttr4c]
let trmedian_400000 = getmedian trlist_400000

let ttr5a = time (fun() -> tree_tester rt5a)
let ttr5b = time (fun() -> tree_tester rt5b)
let ttr5c = time (fun() -> tree_tester rt5c)
let trlist_500000 = [ttr5a;ttr5b;ttr5c]
let trmedian_500000 = getmedian trlist_500000

let ttr6a = time (fun() -> tree_tester rt6a)
let ttr6b = time (fun() -> tree_tester rt6b)
let ttr6c = time (fun() -> tree_tester rt6c)
let trlist_600000 = [ttr6a;ttr6b;ttr6c]
let trmedian_600000 = getmedian trlist_600000

let ttr7a = time (fun() -> tree_tester rt7a)
let ttr7b = time (fun() -> tree_tester rt7b)
let ttr7c = time (fun() -> tree_tester rt7c)
let trlist_700000 = [ttr7a;ttr7b;ttr7c]
let trmedian_700000 = getmedian trlist_700000

let ttr8a = time (fun() -> tree_tester rt8a)
let ttr8b = time (fun() -> tree_tester rt8b)
let ttr8c = time (fun() -> tree_tester rt8c)
let trlist_800000 = [ttr8a;ttr8b;ttr8c]
let trmedian_800000 = getmedian trlist_800000

let ttr9a = time (fun() -> tree_tester rt9a)
let ttr9b = time (fun() -> tree_tester rt9b)
let ttr9c = time (fun() -> tree_tester rt9c)
let trlist_900000 = [ttr9a;ttr9b;ttr9c]
let trmedian_900000 = getmedian trlist_900000

let ttr10a = time (fun() -> tree_tester rt10a)
let ttr10b = time (fun() -> tree_tester rt10b)
let ttr10c = time (fun() -> tree_tester rt10c)
let trlist_1000000 = [ttr10a;ttr10b;ttr10c]
let trmedian_1000000 = getmedian trlist_1000000

let t1a  =  rnd_sort_list 100000
let t2a  =  rnd_sort_list 200000
let t3a  =  rnd_sort_list 300000
let t4a  =  rnd_sort_list 400000
let t5a  =  rnd_sort_list 500000
let t6a  =  rnd_sort_list 600000
let t7a  =  rnd_sort_list 700000
let t8a  =  rnd_sort_list 800000
let t9a  =  rnd_sort_list 900000
let t10a  =  rnd_sort_list 1000000

let t1b  =  rnd_sort_list 100000
let t2b  =  rnd_sort_list 200000
let t3b  =  rnd_sort_list 300000
let t4b  =  rnd_sort_list 400000
let t5b  =  rnd_sort_list 500000
let t6b  =  rnd_sort_list 600000
let t7b  =  rnd_sort_list 700000
let t8b  =  rnd_sort_list 800000
let t9b  =  rnd_sort_list 900000
let t10b  =  rnd_sort_list 1000000

let t1c  =  rnd_sort_list 100000
let t2c  =  rnd_sort_list 200000
let t3c  =  rnd_sort_list 300000
let t4c  =  rnd_sort_list 400000
let t5c  =  rnd_sort_list 500000
let t6c  =  rnd_sort_list 600000
let t7c  =  rnd_sort_list 700000
let t8c  =  rnd_sort_list 800000
let t9c  =  rnd_sort_list 900000
let t10c  =  rnd_sort_list 1000000

let tt1a = time (fun() -> tree_tester t1a)
let tt1b = time (fun() -> tree_tester t2b)
let tt1c = time (fun() -> tree_tester t3c)
let tlist_100000 = [tt1a;tt1b;tt1c]
let tmedian_100000 = getmedian tlist_100000

let tt2a = time (fun() -> tree_tester t2a)
let tt2b = time (fun() -> tree_tester t2b)
let tt2c = time (fun() -> tree_tester t2c)
let tlist_200000 = [tt2a;tt2b;tt2c]
let tmedian_200000 = getmedian tlist_200000

let tt3a = time (fun() -> tree_tester t3a)
let tt3b = time (fun() -> tree_tester t3b)
let tt3c = time (fun() -> tree_tester t3c)
let tlist_300000 = [tt3a;tt3b;tt3c]
let tmedian_300000 = getmedian tlist_300000

let tt4a = time (fun() -> tree_tester t4a)
let tt4b = time (fun() -> tree_tester t4b)
let tt4c = time (fun() -> tree_tester t4c)
let tlist_400000 = [tt4a;tt4b;tt4c]
let tmedian_400000 = getmedian tlist_400000

let tt5a = time (fun() -> tree_tester t5a)
let tt5b = time (fun() -> tree_tester t5b)
let tt5c = time (fun() -> tree_tester t5c)
let tlist_500000 = [tt5a;tt5b;tt5c]
let tmedian_500000 = getmedian tlist_500000

let tt6a = time (fun() -> tree_tester t6a)
let tt6b = time (fun() -> tree_tester t6b)
let tt6c = time (fun() -> tree_tester t6c)
let tlist_600000 = [tt6a;tt6b;tt6c]
let tmedian_600000 = getmedian tlist_600000

let tt7a = time (fun() -> tree_tester t7a)
let tt7b = time (fun() -> tree_tester t7b)
let tt7c = time (fun() -> tree_tester t7c)
let tlist_700000 = [tt7a;tt7b;tt7c]
let tmedian_700000 = getmedian tlist_700000

let tt8a = time (fun() -> tree_tester t8a)
let tt8b = time (fun() -> tree_tester t8b)
let tt8c = time (fun() -> tree_tester t8c)
let tlist_800000 = [tt8a;tt8b;tt8c]
let tmedian_800000 = getmedian tlist_800000

let tt9a = time (fun() -> tree_tester t9a)
let tt9b = time (fun() -> tree_tester t9b)
let tt9c = time (fun() -> tree_tester t9c)
let tlist_900000 = [tt9a;tt9b;tt9c]
let tmedian_900000 = getmedian tlist_900000

let tt10a = time (fun() -> tree_tester t10a)
let tt10b = time (fun() -> tree_tester t10b)
let tt10c = time (fun() -> tree_tester t10c)
let tlist_1000000 = [tt10a;tt10b;tt10c]
let tmedian_1000000 = getmedian tlist_1000000


let file1 = open_out "tree_perf.csv" 
let file = open_out "list_perf.csv"
let _ = 
  Printf.fprintf file1 "%s," "n"; Printf.fprintf file1 "%s," "Tree-Asc"; Printf.fprintf file1 "%s\n" "Tree-Rnd"; 
  Printf.fprintf file1 "%i," 100000; Printf.fprintf file1 "%f," tmedian_100000; Printf.fprintf file1 "%f\n" trmedian_100000;
  Printf.fprintf file1 "%i," 200000; Printf.fprintf file1 "%f," tmedian_200000; Printf.fprintf file1 "%f\n" trmedian_200000;
  Printf.fprintf file1 "%i," 300000; Printf.fprintf file1 "%f," tmedian_300000; Printf.fprintf file1 "%f\n" trmedian_300000;
  Printf.fprintf file1 "%i," 400000; Printf.fprintf file1 "%f," tmedian_400000; Printf.fprintf file1 "%f\n" trmedian_400000;
  Printf.fprintf file1 "%i," 500000; Printf.fprintf file1 "%f," tmedian_500000; Printf.fprintf file1 "%f\n" trmedian_500000;
  Printf.fprintf file1 "%i," 600000; Printf.fprintf file1 "%f," tmedian_600000; Printf.fprintf file1 "%f\n" trmedian_600000;
  Printf.fprintf file1 "%i," 700000; Printf.fprintf file1 "%f," tmedian_700000; Printf.fprintf file1 "%f\n" trmedian_700000;
  Printf.fprintf file1 "%i," 800000; Printf.fprintf file1 "%f," tmedian_800000; Printf.fprintf file1 "%f\n" trmedian_800000;
  Printf.fprintf file1 "%i," 900000; Printf.fprintf file1 "%f," tmedian_900000; Printf.fprintf file1 "%f\n" trmedian_900000;
  Printf.fprintf file1 "%i," 1000000; Printf.fprintf file1 "%f," tmedian_1000000; Printf.fprintf file1 "%f\n" trmedian_1000000;

  Printf.fprintf file "%s," "n"; Printf.fprintf file "%s," "List-Asc"; Printf.fprintf file "%s\n" "List-Rnd"; 
  Printf.fprintf file "%i," 1000; Printf.fprintf file "%f," dmedian_1000; Printf.fprintf file "%f\n" drmedian_1000;
  Printf.fprintf file "%i," 2000; Printf.fprintf file "%f," dmedian_2000; Printf.fprintf file "%f\n" drmedian_2000;
  Printf.fprintf file "%i," 3000; Printf.fprintf file "%f," dmedian_3000; Printf.fprintf file "%f\n" drmedian_3000;
  Printf.fprintf file "%i," 4000; Printf.fprintf file "%f," dmedian_4000; Printf.fprintf file "%f\n" drmedian_4000;
  Printf.fprintf file "%i," 5000; Printf.fprintf file "%f," dmedian_5000; Printf.fprintf file "%f\n" drmedian_5000;
  Printf.fprintf file "%i," 6000; Printf.fprintf file "%f," dmedian_6000; Printf.fprintf file "%f\n" drmedian_6000;
  Printf.fprintf file "%i," 7000; Printf.fprintf file "%f," dmedian_7000; Printf.fprintf file "%f\n" drmedian_7000;
  Printf.fprintf file "%i," 8000; Printf.fprintf file "%f," dmedian_8000; Printf.fprintf file "%f\n" drmedian_8000;
  Printf.fprintf file "%i," 9000; Printf.fprintf file "%f," dmedian_9000; Printf.fprintf file "%f\n" drmedian_9000;
  Printf.fprintf file "%i," 10000; Printf.fprintf file "%f," dmedian_10000; Printf.fprintf file "%f\n" drmedian_10000

