open OUnit2
open Dictionary;;

module Int = struct
  type t = int
  let compare x y =
    match Pervasives.compare x y with
    | x when x<0 -> LT
    | 0 -> EQ
    | _ -> GT
  let format fmt x =
    (*BISECT-IGNORE-BEGIN*)Format.fprintf fmt "%d" x (*BISECT-IGNORE-END*)
end;;

(* The next line creates a dictionary that maps ints to ints. *)
module IntIntDictionary = ListDictionary.Make(Int)(Int);;

(* [choose_matcher f d] returns true if [f d] returns Some x; false if [f d] 
   returns None. *)
let choose_matcher f d = 
  match f d with 
  | Some x -> true
  | None -> false

(** [DictionaryTests] is a functor that takes a dictionary that maps ints to ints
    and returns a test suite for the dictionary.*)
module DictionaryTests = functor (D:Dictionary.Dictionary with type Key.t = int
                                                           and type Value.t = int) -> struct
  let d_empty = D.empty 
  let new_d = D.insert 0 1 D.empty
  let newest_d = D.insert 4 5 (D.insert 3 3 (D.insert 2 2 (D.insert 1 1 new_d)))
  let ins_d = D.insert 4 6 newest_d
  let rem_d = D.remove 4 ins_d 
  let unordered_d = D.insert 0 1 (D.insert 3 3 (D.insert 2 2 (D.insert 1 1 (D.insert 4 5 D.empty))))

  (* [find_matcher k d] returns x if Some x; 0 if None  
     returns None. *)
  let find_matcher k d = 
    match D.find k d with 
    | Some (v) -> v
    | None -> 0

  (** test cases for dictionary D.*)
  let dictionary_tests = [
    "is_empty on empty dict" >:: (fun _ -> 
        assert_equal true (D.is_empty (D.empty) ) );
    "is_empty on nonempty dict" >:: (fun _ -> 
        assert_equal false (D.is_empty new_d) );
    "size empty dict" >:: (fun _ -> 
        assert_equal 0 (D.size D.empty) );
    "size and insert nonempty dict" >:: (fun _ -> 
        assert_equal 1 (D.size new_d) );
    "size and insert 5 len nonempty dict" >:: (fun _ -> 
        assert_equal 5 (D.size newest_d) );
    "insert and find Some v replacement val " >:: (fun _ -> 
        assert_equal 6 (find_matcher 4 ins_d));  
    "find Some v " >:: (fun _ -> 
        assert_equal 1 (find_matcher 0 new_d));
    "find Some v on newest_d " >:: (fun _ -> 
        assert_equal 5 (find_matcher 4 newest_d));
    "remove with bindings and find None val " >:: (fun _ -> 
        assert_equal 0 (find_matcher 4 rem_d) );
    "mem false " >:: (fun _ -> 
        assert_equal false (D.member 4 rem_d) );
    "mem true " >:: (fun _ -> 
        assert_equal true (D.member 3 rem_d) ); 
    "choose some k,v " >:: (fun _ -> 
        assert_equal true (choose_matcher D.choose rem_d) ); 
    "choose None " >:: (fun _ -> 
        assert_equal false (choose_matcher D.choose D.empty) );
    "to_list " >:: (fun _ -> 
        assert_equal [(0,1);(1,1);(2,2);(3,3);(4,5)] (D.to_list unordered_d));
    "fold sum " >:: (fun _ -> 
        assert_equal 22 (D.fold (fun x y z -> x+y+z) 0 newest_d));
  ] 
end 

module ListDictionary_tests = DictionaryTests(IntIntDictionary)

let listDictionary_tests = ListDictionary_tests.dictionary_tests

(** A set that contains strings*)
module String = struct
  type t = string
  let compare x y =
    match Pervasives.compare x y with
    | x when x<0 -> LT
    | 0 -> EQ
    | _ -> GT
  let format fmt x = (*BISECT-IGNORE-BEGIN*)
    Format.fprintf fmt "%s" x(*BISECT-IGNORE-END*)
end;;


(*---------------- Set test casess -------------------*)

module StringSet = DictionarySet.Make(String)(ListDictionary.Make)


(** The following are helper functions to check equality of sets*)

(** [cmp_set_like_lists lst1 lst2] checks equality of lists disregard of the order.
    This function is borrowed from source code of A2. *)
let cmp_set_like_lists lst1 lst2 =
  let uniq1 = List.sort_uniq compare lst1 in
  let uniq2 = List.sort_uniq compare lst2 in
  List.length lst1 = List.length uniq1
  &&
  List.length lst2 = List.length uniq2
  &&
  uniq1 = uniq2


(** [pp_string s] pretty-prints string [s]. 
    This function is borrowed from source code of A2.*)
let pp_string s = "\"" ^ s ^ "\""

(** [pp_list pp_elt lst] pretty-prints list [lst], using [pp_elt]
    to pretty-print each element of [lst]. 
    This function is borrowed from source code of A2.*)
let pp_list pp_elt lst =
  let pp_elts lst =
    let rec loop n acc = function
      | [] -> acc
      | [h] -> acc ^ pp_elt h
      | h1::(h2::t as t') ->
        if n=100 then acc ^ "..."  (* stop printing long list *)
        else loop (n+1) (acc ^ (pp_elt h1) ^ "; ") t'
    in loop 0 "" lst
  in "[" ^ pp_elts lst ^ "]"


(** [SetTests] is a functor that takes a set that contains strings
    and returns a test suite for the dictionary.*)
module SetTests = functor (S: DictionarySet.Set with type Elt.t = string) -> struct
  (** Create string sets for testing *)
  let a_set = S.insert "a" S.empty (* ["a"] *)
  let b_set = S.insert "b" S.empty (* ["a"] *)
  let ab_set = a_set |> S.insert "b" (* ["a"; "b"] *)
  let ac_set = a_set |> S.insert "c" (* ["a"; "c"] *)
  let bc_set = b_set |> S.insert "c" (* ["b"; "c"] *)
  let bd_set = b_set |> S.insert "d" (* ["b"; "d"] *)
  let abc_set = ab_set |> S.insert "c" (* ["a"; "b";"c"] *)
  let abcd_set = abc_set |> S.insert "d" (* ["a"; "b";"c"; "d"] *)

  (** A4 test cases for dictionarySet*)
  let set_tests = [
    "is_empty on empty set" >:: (fun _ -> 
        assert_equal true (S.is_empty (S.empty) ) );
    "is_empty on nonempty set" >:: (fun _ -> 
        assert_equal false (S.is_empty a_set) );
    "size of empty set" >:: (fun _ -> 
        assert_equal 0 (S.size S.empty) );
    "size of [\"a\"]" >:: (fun _ -> 
        assert_equal 1 (S.size a_set) );
    "size of [\"a\";\"b\"; \"c\"; \"d\"]" >:: (fun _ -> 
        assert_equal 4 (S.size abcd_set) );
    "insert no binding in [\"a\"]" >:: (fun _ -> 
        assert_equal a_set (S.insert "a" S.empty) );
    "insert \"a\" to [\"a\"]" >:: (fun _ -> 
        assert_equal a_set (S.insert "a" a_set) );
    "insert \"b\" to [\"a\";\"b\"]" >:: (fun _ -> 
        assert_equal ab_set (S.insert "b" ab_set) );
    "insert \"c\" to [\"a\";\"b\"]" >:: (fun _ -> 
        assert_equal abc_set (S.insert "c" ab_set) );
    "remove no binding in [\"a\"]" >:: (fun _ -> 
        assert_equal a_set (S.remove "b" a_set) );
    "remove c from [\"a\";\"b\"; \"c\"]" >:: (fun _ -> 
        assert_equal ab_set (S.remove "c" abc_set) );
    "remove b from [\"a\";\"b\"; \"c\"]" >:: (fun _ -> 
        assert_equal ac_set (S.remove "b" abc_set) );
    "remove a from [\"a\"]" >:: (fun _ -> 
        assert_equal S.empty (S.remove "a" a_set) ); 
    "mem false set" >:: (fun _ -> 
        assert_equal false (S.member "c" ab_set));
    "mem true set" >:: (fun _ -> 
        assert_equal true (S.member "c" abc_set) );
    "choose on nonempty set " >:: (fun _ -> 
        assert_equal true (choose_matcher S.choose a_set) );
    "choose on empty set " >:: (fun _ -> 
        assert_equal false (choose_matcher S.choose S.empty) );
    "[\"a\"] to_list " >:: (fun _ -> 
        assert_equal ["a"] (S.to_list a_set));
    "[] to_list " >:: (fun _ -> 
        assert_equal [] (S.to_list S.empty));
    "[\"a\"; \"b\"; \"c\"] to_list " >:: (fun _ -> 
        assert_equal ["a"; "b"; "c"] (S.to_list abc_set));
    "fold concatinate on \"abc\"" >:: (fun _ -> 
        assert_equal "cba" (S.fold (^) "" abc_set) );
    "fold concatinate on empty string" >:: (fun _ -> 
        assert_equal "" (S.fold (^) "" S.empty) );
    "intersect of empty and [\"a\"]" >:: (fun _ -> 
        assert_equal S.empty (S.intersect S.empty a_set) );
    "intersect of [\"a\"; \"c\"] and [\"a\"]" >:: (fun _ -> 
        assert_equal a_set (S.intersect ac_set a_set) );
    "intersect of [\"a\"; \"b\"; \"c\"; \"d\"] and [\"a\"; \"b\"; \"c\"]" >:: 
    (fun _ -> assert_equal abc_set (S.intersect abcd_set abc_set) );
    "union of empty and [\"a\"]" >:: (fun _ -> 
        assert_equal a_set (S.union S.empty a_set) );
    "union of [\"a\"] and empty" >:: (fun _ -> 
        assert_equal a_set (S.union a_set S.empty) );
    "union of [\"b\"] and [\"a\"]" >:: 
    (fun _ -> 
       assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
         (S.to_list ab_set) (S.to_list (S.union b_set a_set)) );
    "union of [\"a\"] and [\"b\"]" >:: 
    (fun _ -> 
       assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
         (S.to_list ab_set) (S.to_list (S.union a_set b_set)) );
    "union of [\"a\"; \"c\"] and [\"a\"]" >:: (fun _ -> 
        assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
          (S.to_list ac_set) (S.to_list (S.union ac_set a_set)) );
    "union of [\"a\"; \"b\"] and [\"a\";\"c\"]" >:: (fun _ -> 
        assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
          (S.to_list abc_set) (S.to_list (S.union ac_set ab_set)) );
    "difference of empty and [\"a\"]" >:: (fun _ -> 
        assert_equal a_set (S.difference S.empty a_set) );
    "difference of [\"a\"] and empty" >:: (fun _ -> 
        assert_equal a_set (S.difference a_set S.empty) );
    "difference of [\"b\"] and [\"a\"]" >:: 
    (fun _ -> 
       assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
         (S.to_list ab_set) (S.to_list (S.difference b_set a_set)) );
    "difference of [\"a\"] and [\"b\"]" >:: 
    (fun _ -> 
       assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
         (S.to_list ab_set) (S.to_list (S.difference a_set b_set)) );
    "difference of [\"a\"; \"b\"] and [\"a\"]" >:: (fun _ -> 
        assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
          (S.to_list b_set) (S.to_list (S.difference ab_set a_set)) );
    "difference of [\"a\"; \"b\"] and [\"a\";\"c\"]" >:: (fun _ -> 
        assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
          (S.to_list bc_set) (S.to_list (S.difference ac_set ab_set)) );
    "difference of [\"a\"; \"b\"; \"c\"; \"d\"] and [\"a\";\"c\"]" >:: (fun _ -> 
        assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
          (S.to_list bd_set) (S.to_list (S.difference abcd_set ac_set)) ); 
    "difference of [\"a\";\"c\"] and [\"a\"; \"b\"; \"c\"; \"d\"]" >:: (fun _ -> 
        assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
          (S.to_list bd_set) (S.to_list (S.difference ac_set abcd_set)) );
  ]
end

module DictionarySet_tests = SetTests(StringSet)
let dictionarySet_tests = DictionarySet_tests.set_tests


(*---------------- Engine test -------------------*)

module StrDict = ListDictionary.Make(String)(StringSet)
module StrEngine = Engine.Make(StringSet)(StrDict);;

(** [EngTests] is a functor that takes an engine that contains strings
    and returns a test suite for the dictionary.*)
module EngTests = functor (E: Engine.Engine) -> struct
  let test_dir = "small_tests"
  let test_idx = StrDict.empty |> StrDict.insert ("a.txt")
                   (StringSet.empty |> StringSet.insert "ocaml" 
                    |> StringSet.insert "is" |> StringSet.insert "bae") 
                 |> StrDict.insert ("b.txt")
                   (StringSet.empty |> StringSet.insert "salt" 
                    |> StringSet.insert "bae") 
  let test_words = ["ocaml";"is";"bae";"salt"] 
  let test_to_list = [("ocaml", ["a.txt"]); 
                      ("is", ["a.txt"]);
                      ("bae", ["a.txt"; "b.txt"]);
                      ("salt", ["b.txt"])]
  let test_or_string = ["ocaml", "salt"]
  let test_not_string = []
  let test_or_not = ["a.txt","b.txt"]
  let test_and_not = ["b.txt"]


  (** [contains_all ls1 ls2] check if every elt in ls1 is in ls2. *)
  let rec contains_all ls1 ls2 = 
    (* if ls1 = empty then check if ls2 empty.
       check if first elt of ls1 is mem of ls2 and do it for all elts of ls1 *)
    match ls1,ls2 with 
    | [], _  -> true
    | h::t, x -> if List.mem h x then contains_all t ls2 else false

  (** [equal a b] checks if two lists a and b contain the same elts*)
  let equal a b = (contains_all a b) && (contains_all b a)

  (** [matcher ls1 ls2] checks if for all keys in ls1 their values are same as the
      values for ls2's respective same keys. *)
  let rec matcher ls1 ls2 = 
    match ls1 with 
    | [] -> true
    | h::t -> let c = fst h in if equal (List.assoc c ls1) (List.assoc c ls2) 
      then matcher t ls2 else false

  (** [assoc_list_compare ls1 ls2] checks if keys and values of both assoc lists 
      are the same*)
  let assoc_list_compare ls1 ls2 =  
    (* first call equal on the two lists with only the fst of their pairs (checks keys*)
    (* then for each key of ls1 check whether its value is equal to same key of ls2's
       value using equal *)
    if equal (fst (List.split ls1)) (fst (List.split ls2)) then matcher ls1 ls2 else false

  (** A4 test cases for engine*)
  let engine_tests = [
    "length of words for small_tests" >:: ( fun _ ->
        assert_equal (List.length (test_words)) 
          ("small_tests" |> E.index_of_dir |> E.words |> List.length)); 
    "comparing words for small_tests" >:: (fun _ -> 
        assert_equal true (cmp_set_like_lists (test_words) 
                             (("small_tests"|> E.index_of_dir |> E.words)))); 
    "comparing to_list for small_test" >:: ( fun _ ->
        assert_equal true (assoc_list_compare (test_to_list) 
                             ("small_tests" |> E.index_of_dir |> E.to_list))); 
    "length of words for alice" >:: ( fun _ ->
        assert_equal 3278 ("alice" |> E.index_of_dir |> E.words |> List.length)); 
    "length of words for yellowstone" >:: ( fun _ ->
        assert_equal false (3278 = ("large_tests" |> E.index_of_dir |> E.words 
                                    |> List.length)));  
    "catching exception in index_of_dir" >:: ( fun _ ->
        assert_raises (Not_found) (fun() -> E.index_of_dir "not here")); 
    "or_not nonempty nots for small_tests" >:: ( fun _ ->
        let output = "small_tests" |> E.index_of_dir in
        let out = E.or_not output ["bae"] ["salt"] in
        assert_equal ["a.txt"] out); 
    "or_not empty nots for small_test" >:: ( fun _ ->
        let output = "small_tests" |> E.index_of_dir in
        let out = E.or_not output ["ocaml"] [] in
        assert_equal ["a.txt"] out); 
    "or_not both for small_test" >:: ( fun _ ->
        let output = "small_tests" |> E.index_of_dir in
        let out = E.or_not output ["ocaml";"salt"] [] in
        assert_equal ["a.txt"; "b.txt"] out); 
    "or_not for alice" >:: ( fun _ ->
        let output = "alice" |> E.index_of_dir in
        let out = E.or_not output ["alice"] [] in
        assert_equal ["alice.txt"] out); 
    "and_not both for small_test" >:: ( fun _ ->
        let output = "small_tests" |> E.index_of_dir in
        let out = E.and_not output ["ocaml"; "is"] [] in
        assert_equal ["a.txt"] out); 
    "and_not both for small_test" >:: ( fun _ ->
        let output = "small_tests" |> E.index_of_dir in
        let out = E.and_not output ["ocaml"; "is"] ["bae"] in
        assert_equal [] out); 
    "and_not both for small_test" >:: ( fun _ ->
        let output = "small_tests" |> E.index_of_dir in
        let out = E.and_not output ["bae"; "is"] ["bae"] in
        assert_equal [] out); 
    "and_not both for small_test" >:: ( fun _ ->
        let output = "small_tests" |> E.index_of_dir in
        let out = E.and_not output ["ocaml"; "bae"] ["salt"] in
        assert_equal ["a.txt"] out); 
    "and_not both for alice" >:: ( fun _ ->
        let output = "alice" |> E.index_of_dir in
        let out = E.and_not output ["alice";"yellowstone"] [] in
        assert_equal [] out); 
  ]
end

(** Testing dictionary engine.*)
module Engine_tests = EngTests(StrEngine)
let engine_tests = Engine_tests.engine_tests



(** Test cases for A5.*)

(** Testing tree dictionary*)
module IntTreeDictionary = TreeDictionary.Make(Int)(Int)
module TreeDictionary_tests = DictionaryTests(IntTreeDictionary)
let treeDictionary_tests = TreeDictionary_tests.dictionary_tests 

(** Testing tree set.*)
module StrTreeSet = DictionarySet.Make(String)(ListDictionary.Make)
module TreeSet_tests = SetTests(StrTreeSet)
let treeSet_tests = TreeSet_tests.set_tests 

(** Testing tree engine.*)
module TreeEngine = TreeEngine.TreeEngine
module TreeEngine_tests = EngTests(TreeEngine)
let tree_engine_tests = TreeEngine_tests.engine_tests


(** Suite for the test cases*)
let suite = "search test suite" >::: List.flatten [
    (*listDictionary_tests;
      dictionarySet_tests; 
      engine_tests;*)
    listDictionary_tests;
    treeDictionary_tests;
    treeSet_tests; 
    tree_engine_tests 
  ]


(* Run the tests *)
let _ = run_test_tt_main suite 

